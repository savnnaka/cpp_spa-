#include "operations.h"

Operation::Operation(const Shape& shape_a, const Shape& shape_b)
    : sub_shape_a{shape_a.clone()}, sub_shape_b{shape_b.clone()}
{

}

AABB Operation::getBounds_impl() const
{
    return sub_shape_a.getBounds()+sub_shape_b.getBounds();
}

And::And(const Shape& shape_a, const Shape& shape_b)
    : Operation(shape_a, shape_b)   // call constructor of base class
{
    // call clone_impl(), ist aber privat
}

bool And::isInside_impl(const Point3D& p) const 
{
    // wie auf shape a und b zugreifen ??
    return false;
}
