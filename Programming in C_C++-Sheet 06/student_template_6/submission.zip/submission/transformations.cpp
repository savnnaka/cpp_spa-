#include "transformations.h"
#include <cmath>

// helper function for 2D rotations
std::pair<float, float> rotate2D(float x, float y, float angle)
{
    float sin, cos;
    sincosf(angle, &sin, &cos); // in Mac OSX sincosf may not be found, try __sincosf. But you need to use sincosf for submission.

    return {cos*x-sin*y, sin*x+cos*y};
}


Transformation::Transformation(const Shape& shape)
    : sub_shape{shape.clone()}
{

}
