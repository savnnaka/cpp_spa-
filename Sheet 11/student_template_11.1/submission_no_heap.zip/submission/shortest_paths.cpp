#include "shortest_paths.h"
#include <algorithm>
#include <cstddef>
#include <iterator>
#include <optional>
#include <utility>
#include <iostream>
#include <cmath>
#include <vector>

size_t ShortestPaths::getNodeIdByName(const std::string& name) const {
    // NOTE: if you like, you can make this more efficient by caching the mapping in a mutable hash map that gets reset when calling non-const functions
    const auto it = std::find_if(adjacency_matrix.begin(), adjacency_matrix.end(), [=](const Location& row) -> bool { return row.name == name; });
    if (it == adjacency_matrix.end())
        throw std::runtime_error("Location "+name+" not found");
    return static_cast<size_t>(std::distance(adjacency_matrix.begin(), it));
}

std::vector<size_t> ShortestPaths::compute_shortest_path(size_t from, size_t to) const
{
    /// your result path
    std::vector<size_t> result;
    /// increment this for every node that you pop from the queue
    size_t num_visited = 0;

    // TODO: your code here
    size_t SIZE = this->size();
    Location fromL = this->at(from);

    // Queue toExplore initiallized with starting point
    //std::priority_queue<size_t, std::vector<size_t>, Compare> toExplore2;
    std::vector<size_t> toExplore;
    toExplore.push_back(from);

    // Points that have already been visited
    std::vector<bool> visited;
    visited.resize(SIZE, false);

    // distances and predecessors
    std::vector<std::optional<float>> dists;
    dists.resize(SIZE);
    dists.at(from) = 0;
    std::vector<std::optional<size_t>> predecessors;
    predecessors.resize(SIZE);

    bool notFound = true;

    // while Queue is not empty
    while( !std::empty(toExplore) && notFound ){
        // fetch the point with the shortest distance from the startpoint
        float minDist = INFINITY;
        size_t elem;
        for(size_t i=0; i<toExplore.size(); i++){
            size_t curr = toExplore.at(i);
            if(dists.at(curr).has_value() && dists.at(curr).value() < minDist){
                minDist = dists.at(curr).value();
                elem = curr;
            }
        }
        // element is now visited
        ++num_visited;
        std::erase(toExplore, elem);
        visited.at(elem) = true;
        // who are the neighbours of elem
        Location elemL = this->at(elem);
        // loop through the whole adj matrix
        for(size_t i=0; i<this->size(); i++){
            // if there's a value stored, it's a neighbour
            if(elemL.at(i).has_value()){
                // if i is the goal, terminate
                if( i == to){
                    predecessors.at(i) = elem;
                    notFound = false;
                    break;
                }
                // update shortest paths to ith neighbour & set predecessor
                float newDist = elemL.at(i).value() + dists.at(elem).value();
                if( !dists.at(i).has_value() || (dists.at(i).value() > newDist) ){
                    dists.at(i) = newDist;
                    predecessors.at(i) = elem;
                }
                // add to queue
                if( !visited.at(i) ){
                    toExplore.push_back(i);
                }
            }
        }

    }

    // result.push_back(to);
    
    if( predecessors.at(to).has_value() ){
    // trace back the path
        size_t elem = to;
        while( elem != from ){
            result.push_back(elem);
            elem = predecessors.at(elem).value();
        }
    } 

    std::cout << "Nodes visited: " << num_visited << std::endl;
    
    std::reverse(result.begin(), result.end());
    return result;
}

